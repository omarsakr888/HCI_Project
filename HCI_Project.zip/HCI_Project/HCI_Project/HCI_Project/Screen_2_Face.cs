using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Drawing.Text;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace HCI_Project
{
    public partial class Screen_2_Face : Form
    {
        private static readonly Color Bg = Color.FromArgb(12, 16, 19);
        private static readonly Color Panel = Color.FromArgb(14, 21, 24);
        private static readonly Color Teal = Color.FromArgb(0, 212, 170);
        private static readonly Color TextMain = Color.FromArgb(236, 236, 236);
        private static readonly Color TextMuted = Color.FromArgb(120, 130, 136);

        private Rectangle _leftZone;
        private Rectangle _rightZone;
        private Rectangle _cameraRect;
        private Rectangle _faceRect;
        private Rectangle _nameBadgeRect;
        private Rectangle _rightCardRect;
        private Rectangle _phoneChipRect;
        private Rectangle _progressTrack;
        private Rectangle _manualTextRect;
        private Rectangle _manualButtonRect;

        private float _scanPhase;
        private float _progressPhase;
        private int _tickCount;
        private bool _faceMatched;
        private bool _showFallback;
        private volatile bool _stopServer;
        private TcpListener _listener;
        private Thread _acceptThread;
        private string _detectedPhoneLabel = "Scanning...";
        private string _athleteLabel = "Unknown";

        public Screen_2_Face()
        {
            InitializeComponent();
            DoubleBuffered = true;
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            Bounds = Screen.PrimaryScreen.Bounds;
            LayoutControls();
            StartTcpServer();
            timerUi.Start();
        }

        private void LoginForm_Shown(object sender, EventArgs e)
        {
            _faceMatched = false;
            _showFallback = false;
            _tickCount = 0;
            timerUi.Start();
        }

        private void LoginForm_SizeChanged(object sender, EventArgs e)
        {
            LayoutControls();
            Invalidate();
        }

        private void LayoutControls()
        {
            var w = ClientSize.Width;
            var h = ClientSize.Height;
            const int margin = 40;
            var top = 78;
            var bottom = h - 40;
            var contentH = Math.Max(320, bottom - top);
            var split = (int)(w * 0.58f);

            _leftZone = new Rectangle(margin, top, split - margin - 10, contentH);
            _rightZone = new Rectangle(split + 10, top, w - split - margin - 10, contentH);

            _cameraRect = new Rectangle(
                _leftZone.Left + 20,
                _leftZone.Top + 130,
                _leftZone.Width - 40,
                _leftZone.Height - 170);

            var faceW = (int)(_cameraRect.Width * 0.46f);
            var faceH = (int)(_cameraRect.Height * 0.52f);
            _faceRect = new Rectangle(
                _cameraRect.Left + (_cameraRect.Width - faceW) / 2,
                _cameraRect.Top + (_cameraRect.Height - faceH) / 2 - 20,
                faceW,
                faceH);

            _nameBadgeRect = new Rectangle(
                _faceRect.Left + (_faceRect.Width - 170) / 2,
                _faceRect.Bottom + 24,
                170,
                38);

            _rightCardRect = new Rectangle(_rightZone.Left + 20, _rightZone.Top + 18, _rightZone.Width - 40, _rightZone.Height - 40);
            _phoneChipRect = new Rectangle(_rightCardRect.Left + 20, _rightCardRect.Top + 24, _rightCardRect.Width - 40, 60);
            _progressTrack = new Rectangle(_rightCardRect.Left + 82, _rightCardRect.Top + 435, _rightCardRect.Width - 164, 7);

            _manualTextRect = new Rectangle(_rightCardRect.Left + 20, _rightCardRect.Top + 560, _rightCardRect.Width - 40, 36);
            _manualButtonRect = new Rectangle(_rightCardRect.Left + 20, _rightCardRect.Top + 620, _rightCardRect.Width - 40, 42);

            txtManualName.Location = _manualTextRect.Location;
            txtManualName.Size = _manualTextRect.Size;

            btnSecureSession.Location = _manualButtonRect.Location;
            btnSecureSession.Size = _manualButtonRect.Size;
        }

        private void timerUi_Tick(object sender, EventArgs e)
        {
            _tickCount++;
            _scanPhase += 0.032f;
            _progressPhase += 0.019f;
            if (_scanPhase > Math.PI * 2) _scanPhase -= (float)(Math.PI * 2);
            if (_progressPhase > Math.PI * 2) _progressPhase -= (float)(Math.PI * 2);

            txtManualName.Visible = _showFallback;
            btnSecureSession.Visible = _showFallback;

            Invalidate();
        }

        private void LoginForm_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            g.Clear(Bg);

            DrawHeader(g);
            DrawLeftZone(g);
            DrawRightZone(g);
        }

        private void DrawHeader(Graphics g)
        {
            using (var b = new SolidBrush(Color.FromArgb(16, 22, 26)))
            {
                g.FillRectangle(b, new Rectangle(0, 0, ClientSize.Width, 56));
            }

            using (var font = new Font("Segoe UI", 12f, FontStyle.Bold))
            using (var brush = new SolidBrush(Color.FromArgb(220, 220, 220)))
            {
                g.DrawString("FORMGUARD", font, brush, 34, 16);
            }

            using (var iconFont = new Font("Segoe UI Symbol", 14f))
            using (var iconBrush = new SolidBrush(Teal))
            {
                var x = ClientSize.Width - 112;
                g.DrawString("\u2699", iconFont, iconBrush, x, 16);
                g.DrawString("\u003F", iconFont, iconBrush, x + 34, 16);
                g.DrawString("\u23FB", iconFont, iconBrush, x + 66, 16);
            }
        }

        private void DrawLeftZone(Graphics g)
        {
            using (var subtitleFont = new Font("Consolas", 10f, FontStyle.Bold))
            using (var titleFont = new Font("Segoe UI", 30f, FontStyle.Regular))
            using (var teal = new SolidBrush(Teal))
            using (var white = new SolidBrush(TextMain))
            {
                g.DrawString("BIOMETRIC SCAN ACTIVE", subtitleFont, teal, _leftZone.Left + 10, _leftZone.Top + 16);
                g.DrawString("Stand in front of the camera", titleFont, white, _leftZone.Left + 10, _leftZone.Top + 34);
            }

            using (var panelBrush = new SolidBrush(Panel))
            using (var path = RoundedRect(_cameraRect, 24))
            {
                g.FillPath(panelBrush, path);
            }

            using (var ringPen = new Pen(Color.FromArgb(60, Teal), 2f))
            using (var lensBrush = new SolidBrush(Color.FromArgb(22, 30, 34)))
            {
                var lensR = Math.Min(_faceRect.Width, _faceRect.Height) / 2f + 56f;
                var cx = _faceRect.X + _faceRect.Width / 2f;
                var cy = _faceRect.Y + _faceRect.Height / 2f;
                g.FillEllipse(lensBrush, cx - lensR, cy - lensR, lensR * 2, lensR * 2);
                g.DrawEllipse(ringPen, cx - lensR, cy - lensR, lensR * 2, lensR * 2);
            }

            DrawViewfinderCorners(g, _faceRect, Teal, 30, 2.8f);

            var scanY = _faceRect.Top + (int)((_faceRect.Height - 2) * (0.5f + 0.5f * Math.Sin(_scanPhase)));
            using (var scanPen = new Pen(Color.FromArgb(160, Teal), 2f))
            {
                g.DrawLine(scanPen, _faceRect.Left + 24, scanY, _faceRect.Right - 24, scanY);
            }

            if (_faceMatched)
            {
                using (var path = RoundedRect(_nameBadgeRect, 18))
                using (var b = new SolidBrush(Teal))
                using (var font = new Font("Segoe UI", 11f, FontStyle.Bold))
                using (var txt = new SolidBrush(Color.FromArgb(10, 24, 26)))
                {
                    g.FillPath(b, path);
                    var t = _athleteLabel;
                    var sz = g.MeasureString(t, font);
                    g.DrawString(t, font, txt, _nameBadgeRect.X + (_nameBadgeRect.Width - sz.Width) / 2f, _nameBadgeRect.Y + 8);
                }
            }
        }

        private void DrawRightZone(Graphics g)
        {
            using (var panelBrush = new SolidBrush(Color.FromArgb(10, 16, 20)))
            using (var panelPath = RoundedRect(_rightCardRect, 22))
            {
                g.FillPath(panelBrush, panelPath);
            }

            using (var chipBrush = new SolidBrush(Color.FromArgb(22, 30, 34)))
            using (var chipPath = RoundedRect(_phoneChipRect, 28))
            using (var iconFont = new Font("Segoe UI Symbol", 14f))
            using (var txtFont = new Font("Segoe UI", 11f, FontStyle.Regular))
            using (var txtBold = new Font("Segoe UI", 12f, FontStyle.Bold))
            using (var iconBrush = new SolidBrush(Teal))
            using (var muted = new SolidBrush(TextMuted))
            using (var white = new SolidBrush(TextMain))
            {
                g.FillPath(chipBrush, chipPath);
                g.DrawString("\u2630", iconFont, iconBrush, _phoneChipRect.Left + 16, _phoneChipRect.Top + 17);
                g.DrawString("Link Status: Bluetooth Feed", txtFont, muted, _phoneChipRect.Left + 50, _phoneChipRect.Top + 11);
                g.DrawString(_detectedPhoneLabel, txtBold, white, _phoneChipRect.Left + 50, _phoneChipRect.Top + 31);
            }

            var avatar = new Rectangle(_rightCardRect.Left + (_rightCardRect.Width - 110) / 2, _rightCardRect.Top + 170, 110, 110);
            using (var avatarBrush = new SolidBrush(Color.FromArgb(26, 34, 38)))
            using (var pen = new Pen(Color.FromArgb(70, Teal), 1.8f))
            using (var txtBrush = new SolidBrush(TextMain))
            using (var font = new Font("Segoe UI", 28f, FontStyle.Bold))
            {
                g.FillEllipse(avatarBrush, avatar);
                g.DrawEllipse(pen, avatar);
                var t = "AS";
                var sz = g.MeasureString(t, font);
                g.DrawString(t, font, txtBrush, avatar.X + (avatar.Width - sz.Width) / 2f, avatar.Y + (avatar.Height - sz.Height) / 2f - 2);
            }

            using (var textFont = new Font("Segoe UI", 24f, FontStyle.Regular))
            using (var tealBrush = new SolidBrush(Teal))
            {
                var msg = _faceMatched ? "Face matched — welcome back" : "Matching face signature...";
                var sz = g.MeasureString(msg, textFont);
                g.DrawString(msg, textFont, tealBrush, _rightCardRect.Left + (_rightCardRect.Width - sz.Width) / 2f, _rightCardRect.Top + 315);
            }

            using (var trackBrush = new SolidBrush(Color.FromArgb(38, 52, 58)))
            using (var fillBrush = new SolidBrush(Teal))
            using (var trackPath = RoundedRect(_progressTrack, 4))
            {
                g.FillPath(trackBrush, trackPath);
                var progress = _faceMatched ? 1f : 0.12f + 0.38f * (0.5f + 0.5f * (float)Math.Sin(_progressPhase));
                var fill = new Rectangle(_progressTrack.X, _progressTrack.Y, (int)(_progressTrack.Width * progress), _progressTrack.Height);
                using (var fillPath = RoundedRect(fill, 4))
                {
                    g.FillPath(fillBrush, fillPath);
                }
            }

            using (var sepPen = new Pen(Color.FromArgb(34, 46, 50)))
            using (var capFont = new Font("Consolas", 10f))
            using (var mutedBrush = new SolidBrush(TextMuted))
            using (var white = new SolidBrush(Color.FromArgb(180, 180, 180)))
            {
                var y = _rightCardRect.Top + 510;
                g.DrawLine(sepPen, _rightCardRect.Left + 20, y, _rightCardRect.Left + 120, y);
                g.DrawLine(sepPen, _rightCardRect.Right - 120, y, _rightCardRect.Right - 20, y);
                g.DrawString("SYSTEM FALLBACK", capFont, mutedBrush, _rightCardRect.Left + (_rightCardRect.Width - 120) / 2f, y - 9);
                using (var fallbackFont = new Font("Segoe UI", 10f))
                {
                    g.DrawString("Face not recognised — enter name manually", fallbackFont, white, _rightCardRect.Left + 20, y + 24);
                }
            }
        }

        private static void DrawViewfinderCorners(Graphics g, Rectangle rect, Color color, int len, float thickness)
        {
            using (var p = new Pen(color, thickness))
            {
                g.DrawLine(p, rect.Left, rect.Top, rect.Left + len, rect.Top);
                g.DrawLine(p, rect.Left, rect.Top, rect.Left, rect.Top + len);

                g.DrawLine(p, rect.Right - len, rect.Top, rect.Right, rect.Top);
                g.DrawLine(p, rect.Right, rect.Top, rect.Right, rect.Top + len);

                g.DrawLine(p, rect.Left, rect.Bottom, rect.Left + len, rect.Bottom);
                g.DrawLine(p, rect.Left, rect.Bottom - len, rect.Left, rect.Bottom);

                g.DrawLine(p, rect.Right - len, rect.Bottom, rect.Right, rect.Bottom);
                g.DrawLine(p, rect.Right, rect.Bottom - len, rect.Right, rect.Bottom);
            }
        }

        private static GraphicsPath RoundedRect(Rectangle r, int radius)
        {
            var path = new GraphicsPath();
            var d = radius * 2;
            path.AddArc(r.Left, r.Top, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        private void btnSecureSession_Click(object sender, EventArgs e)
        {
            _showFallback = false;
            txtManualName.Clear();
            Invalidate();
        }

        private void LoginForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Close();
            }
            else if (e.KeyCode == Keys.F9)
            {
                _showFallback = !_showFallback;
                if (_showFallback)
                {
                    _faceMatched = false;
                }
                Invalidate();
            }
        }

        private void StartTcpServer()
        {
            _stopServer = false;
            _acceptThread = new Thread(AcceptLoop)
            {
                IsBackground = true,
                Name = "Screen2TcpAccept"
            };
            _acceptThread.Start();
        }

        private void AcceptLoop()
        {
            while (!_stopServer)
            {
                TcpListener listener = null;
                try
                {
                    listener = new TcpListener(IPAddress.Loopback, 5050);
                    listener.Start();
                    _listener = listener;
                    while (!_stopServer)
                    {
                        try
                        {
                            var client = listener.AcceptTcpClient();
                            ThreadPool.QueueUserWorkItem(_ => HandleClient(client));
                        }
                        catch (SocketException)
                        {
                            if (_stopServer)
                            {
                                break;
                            }
                            Thread.Sleep(50);
                        }
                        catch (ObjectDisposedException)
                        {
                            break;
                        }
                    }
                }
                catch
                {
                    Thread.Sleep(500);
                }
                finally
                {
                    try { listener?.Stop(); } catch { }
                    if (ReferenceEquals(_listener, listener))
                    {
                        _listener = null;
                    }
                }
            }
        }

        private void HandleClient(object state)
        {
            var client = (TcpClient)state;
            try
            {
                using (client)
                using (var stream = client.GetStream())
                using (var reader = new StreamReader(stream, Encoding.UTF8, false, 1024, leaveOpen: false))
                {
                    string line;
                    while (!_stopServer && (line = reader.ReadLine()) != null)
                    {
                        var cmd = line.Trim();
                        if (cmd.Length == 0)
                        {
                            continue;
                        }

                        SafeInvoke(() => OnTcpCommand(cmd));
                    }
                }
            }
            catch
            {
                // Connection drops are normal.
            }
        }

        private void SafeInvoke(Action action)
        {
            try
            {
                if (IsDisposed)
                {
                    return;
                }

                if (InvokeRequired)
                {
                    BeginInvoke(action);
                }
                else
                {
                    action();
                }
            }
            catch (ObjectDisposedException)
            {
            }
            catch (InvalidOperationException)
            {
            }
        }

        private void OnTcpCommand(string cmd)
        {
            if (cmd.StartsWith("DETECTED_PHONE:", StringComparison.OrdinalIgnoreCase))
            {
                var name = cmd.Substring("DETECTED_PHONE:".Length).Trim();
                if (name.Length > 0)
                {
                    _detectedPhoneLabel = name;
                    if (!_faceMatched)
                    {
                        _athleteLabel = name;
                    }
                    Invalidate();
                }
                return;
            }

            if (cmd.StartsWith("ATHLETE_NAME:", StringComparison.OrdinalIgnoreCase))
            {
                var name = cmd.Substring("ATHLETE_NAME:".Length).Trim();
                if (name.Length > 0)
                {
                    _athleteLabel = name;
                    Invalidate();
                }
                return;
            }

            if (cmd.Equals("PHONE_NEAR", StringComparison.OrdinalIgnoreCase))
            {
                _faceMatched = true;
                Invalidate();
                return;
            }

            if (cmd.Equals("DEVICE_LOST", StringComparison.OrdinalIgnoreCase))
            {
                _faceMatched = false;
                _athleteLabel = _detectedPhoneLabel;
                Invalidate();
                return;
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _stopServer = true;
            try { _listener?.Stop(); } catch { }
            base.OnFormClosing(e);
        }
    }
}
